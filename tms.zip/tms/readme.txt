Login Details for admin : 

Open Your browser put inside browser “http://localhost/tms/admin”

Username: admin

Password: Test@123

Login Details for user: 

Open Your browser put inside browser “http://localhost/tms/”

Username: anuj@gmail.com

Password: Test@123